package diglex.bridge.xml.model;

/**
 * Created by IntelliJ IDEA.
 * User: Gleb Kanterov
 * Date: 13.04.11
 * Time: 17:15
 */
public enum MatchMode {
    AbsoluteMeaningful,
    NotMeaningful,
    RelativeMeaningful
}
