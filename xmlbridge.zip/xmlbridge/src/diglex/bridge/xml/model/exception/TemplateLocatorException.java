package diglex.bridge.xml.model.exception;

/**
 * Created by IntelliJ IDEA.
 * User: Gleb Kanterov
 * Date: 13.04.11
 * Time: 19:04
 */
public class TemplateLocatorException extends Exception {
    public TemplateLocatorException(String message) {
        super(message);
    }
}
