package diglex.bridge.xml.model.exception;

/**
 * Created by IntelliJ IDEA.
 * User: Gleb Kanterov
 * Date: 13.04.11
 * Time: 19:01
 */
public class TemplateReference {
}
